import React, { useState } from 'react';
import { Objective, Role } from '../types';
import { CheckCircle2, Circle, Clock, Plus, Trash2, Target } from 'lucide-react';

interface ObjectivesViewProps {
  objectives: Objective[];
  setObjectives: React.Dispatch<React.SetStateAction<Objective[]>>;
  role: Role;
}

export const ObjectivesView: React.FC<ObjectivesViewProps> = ({ objectives, setObjectives, role }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<Objective['category']>('prayer');

  const handleToggleStatus = (id: string) => {
    setObjectives(prev => prev.map(obj => {
      if (obj.id === id) {
        const nextStatus = obj.status === 'completed' ? 'pending' : 'completed';
        return { ...obj, status: nextStatus };
      }
      return obj;
    }));
  };

  const handleAddObjective = () => {
    if (!newTitle.trim()) return;
    const newObj: Objective = {
      id: Date.now().toString(),
      title: newTitle,
      description: 'Nuevo objetivo añadido.',
      category: newCategory,
      status: 'pending',
      dueDate: new Date().toISOString().split('T')[0]
    };
    setObjectives([...objectives, newObj]);
    setNewTitle('');
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    setObjectives(prev => prev.filter(o => o.id !== id));
  };

  const categories = {
    prayer: { label: 'Oración', color: 'bg-blue-100 text-blue-700' },
    reading: { label: 'Lectura', color: 'bg-emerald-100 text-emerald-700' },
    virtue: { label: 'Virtud', color: 'bg-purple-100 text-purple-700' },
    action: { label: 'Acción', color: 'bg-amber-100 text-amber-700' }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <header className="mb-8 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 serif">Objetivos y Propósitos</h2>
          <p className="text-slate-500 mt-2">
            {role === 'director' 
              ? 'Asigna y supervisa las tareas espirituales de tu dirigido.' 
              : 'Revisa y marca el progreso de tus compromisos espirituales.'}
          </p>
        </div>
        {role === 'director' && (
          <button 
            onClick={() => setIsAdding(!isAdding)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow-sm transition-all"
          >
            <Plus size={18} />
            <span>Nuevo Objetivo</span>
          </button>
        )}
      </header>

      {isAdding && (
        <div className="mb-6 p-6 bg-white rounded-xl shadow-sm border border-indigo-100 animate-in fade-in slide-in-from-top-4">
          <h3 className="font-semibold text-slate-800 mb-4">Añadir Nuevo Objetivo</h3>
          <div className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Título</label>
              <input 
                type="text" 
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Ej: Rezar el Ángelus al mediodía"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Categoría</label>
              <select 
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="prayer">Oración</option>
                <option value="reading">Lectura Espiritual</option>
                <option value="virtue">Virtud / Carácter</option>
                <option value="action">Apostolado / Acción</option>
              </select>
            </div>
            <div className="flex gap-2 justify-end mt-2">
              <button 
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancelar
              </button>
              <button 
                onClick={handleAddObjective}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Guardar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {objectives.map((obj) => (
          <div key={obj.id} className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex items-start gap-4 hover:shadow-md transition-shadow group">
            <button 
              onClick={() => handleToggleStatus(obj.id)}
              className={`mt-1 flex-shrink-0 transition-colors ${
                obj.status === 'completed' ? 'text-emerald-500' : 'text-slate-300 hover:text-emerald-400'
              }`}
            >
              {obj.status === 'completed' ? <CheckCircle2 size={24} /> : <Circle size={24} />}
            </button>
            
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h3 className={`font-semibold text-lg ${obj.status === 'completed' ? 'text-slate-400 line-through decoration-slate-300' : 'text-slate-800'}`}>
                  {obj.title}
                </h3>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${categories[obj.category].color}`}>
                  {categories[obj.category].label}
                </span>
              </div>
              <p className={`text-slate-600 mt-1 ${obj.status === 'completed' ? 'text-slate-400' : ''}`}>
                {obj.description}
              </p>
              {obj.dueDate && (
                <div className="flex items-center gap-1 mt-3 text-xs text-slate-400">
                  <Clock size={12} />
                  <span>Meta: {obj.dueDate}</span>
                </div>
              )}
            </div>

            {role === 'director' && (
              <button 
                onClick={() => handleDelete(obj.id)}
                className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 size={18} />
              </button>
            )}
          </div>
        ))}

        {objectives.length === 0 && (
          <div className="text-center py-12 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
            <Target size={48} className="mx-auto mb-3 opacity-50" />
            <p>No hay objetivos activos por el momento.</p>
          </div>
        )}
      </div>
    </div>
  );
};