import React from 'react';
import { BookOpen, Target, ScrollText, Sparkles, UserCircle, RefreshCcw } from 'lucide-react';
import { Role } from '../types';

interface NavigationProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  role: Role;
  toggleRole: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, setCurrentView, role, toggleRole }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Resumen', icon: BookOpen },
    { id: 'objectives', label: 'Objetivos', icon: Target },
    { id: 'journal', label: 'Sesiones', icon: ScrollText },
    { id: 'assistant', label: 'Asistente', icon: Sparkles },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 bg-white h-screen border-r border-slate-200 flex-col fixed left-0 top-0 z-10 shadow-sm">
        <div className="p-6 border-b border-slate-100">
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2 serif">
            <span className="text-indigo-600">✦</span> Anima
          </h1>
          <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider">Dirección Espiritual</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 font-medium'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-100 bg-slate-50">
          <div className="flex items-center gap-3 mb-4 px-2">
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
              <UserCircle size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-900">
                {role === 'director' ? 'P. Director' : 'Juan (Dirigido)'}
              </p>
              <p className="text-xs text-slate-500 capitalize">{role}</p>
            </div>
          </div>
          
          <button 
            onClick={toggleRole}
            className="w-full flex items-center justify-center gap-2 text-xs font-medium text-slate-500 hover:text-indigo-600 border border-slate-200 hover:border-indigo-200 rounded-md py-2 transition-colors"
          >
            <RefreshCcw size={14} />
            Cambiar Perspectiva
          </button>
        </div>
      </div>

      {/* Mobile Bottom Bar */}
      <div className="md:hidden fixed bottom-0 left-0 w-full bg-white border-t border-slate-200 flex justify-around items-center px-2 py-3 z-50 shadow-lg pb-safe">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`flex flex-col items-center justify-center w-16 gap-1 ${
                isActive ? 'text-indigo-600' : 'text-slate-400'
              }`}
            >
              <div className={`p-1 rounded-full ${isActive ? 'bg-indigo-50' : ''}`}>
                <Icon size={24} />
              </div>
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
        <button onClick={toggleRole} className="flex flex-col items-center justify-center w-16 gap-1 text-slate-400">
             <div className="p-1">
                <RefreshCcw size={20} />
             </div>
             <span className="text-[10px] font-medium">Rol</span>
        </button>
      </div>
    </>
  );
};