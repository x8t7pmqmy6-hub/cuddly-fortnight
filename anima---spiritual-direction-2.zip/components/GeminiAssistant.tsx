import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage, Role } from '../types';
import { Send, Sparkles, Loader2, Info } from 'lucide-react';

interface GeminiAssistantProps {
  role: Role;
}

export const GeminiAssistant: React.FC<GeminiAssistantProps> = ({ role }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: role === 'director' 
        ? "Saludos. Puedo ayudarte a analizar los informes de dirección basándome en los 5 puntos (Estado general, Dimensión vertical, Horizontal, Interior y Otros) o sugerir recursos." 
        : "Paz y bien. Soy tu asistente para preparar tu dirección espiritual. ¿Necesitas ayuda para examinar alguna dimensión en particular (General, Vertical, Horizontal, Interior)?",
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const apiKey = process.env.API_KEY || ''; 
      const ai = new GoogleGenAI({ apiKey });
      
      const systemInstruction = `
        Eres un asistente de dirección espiritual católica experto, que sigue estrictamente el siguiente esquema de 5 puntos para el examen de vida:

        1. Estado General: Salud, trabajo/estudios, tono vital, tentaciones, éxitos.
        2. Dimensión Vertical: Relación con Dios, oración, sacramentos, devoción mariana, presencia de Dios.
        3. Dimensión Horizontal: Trato con los demás, caridad, familia, apostolado.
        4. Dirección Interior: Carácter, virtudes, lucha ascética, abnegación, humildad, orden.
        5. Otras cosas: Planes y dudas.

        Tu rol es:
        - Ayudar al usuario (sea director o dirigido) a profundizar en estos puntos.
        - Si el usuario dice "no sé qué poner en Dimensión Vertical", sugiérele preguntas sobre su oración, misa o confesión basándote en el esquema.
        - Usar un tono sereno, doctrinalmente seguro (Católico) y empático.
        - Citar a santos o la escritura cuando sea oportuno para iluminar un punto del esquema.
        
        Usuario actual: ${role === 'director' ? 'Director Espiritual' : 'Dirigido'}.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: systemInstruction,
        },
        contents: [
            ...messages.filter(m => m.id !== 'welcome').map(m => ({
                role: m.role,
                parts: [{ text: m.text }]
            })),
            { role: 'user', parts: [{ text: input }] }
        ]
      });

      const text = response.text || "Lo siento, no pude generar una respuesta en este momento.";

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: text,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error("Error calling Gemini:", error);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "Hubo un error al conectar con el asistente. Por favor verifica tu conexión o intenta más tarde.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-indigo-50 p-4 border-b border-indigo-100 flex items-center justify-between">
        <div className="flex items-center gap-2 text-indigo-800">
          <Sparkles size={20} />
          <h3 className="font-semibold">Asistente Teológico</h3>
        </div>
        <div className="text-xs text-indigo-600 bg-white px-2 py-1 rounded-full border border-indigo-100">
          Gemini 2.5 Flash
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl p-4 shadow-sm ${
                msg.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none'
              }`}
            >
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</p>
              <span className={`text-[10px] mt-2 block opacity-70 ${msg.role === 'user' ? 'text-indigo-100' : 'text-slate-400'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
              <Loader2 size={16} className="animate-spin text-indigo-600" />
              <span className="text-xs text-slate-500">Pensando...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-slate-100">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Escribe tu consulta o duda espiritual..."
            className="flex-1 p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="p-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send size={20} />
          </button>
        </div>
        <p className="text-[10px] text-slate-400 mt-2 text-center flex items-center justify-center gap-1">
          <Info size={10} />
          La IA puede cometer errores. Utiliza la información como apoyo, no como dogma infalible.
        </p>
      </div>
    </div>
  );
};