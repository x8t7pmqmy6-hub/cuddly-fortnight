import React, { useState } from 'react';
import { DirectionSession, Role, SessionData } from '../types';
import { FileText, Plus, ChevronDown, ChevronUp, Save, Calendar, CheckCheck, Sparkles, Loader2, ListChecks } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface JournalViewProps {
  entries: DirectionSession[];
  setEntries: React.Dispatch<React.SetStateAction<DirectionSession[]>>;
  role: Role;
}

const SCHEMA_GUIDES = {
  general: "Salud, estudios/trabajo, tono espiritual/psíquico (alegría, paz, decaimiento), tentaciones, fallos comunes, éxitos, amistades, descanso, deseo de avance.",
  vertical: "Amor a Dios, jerarquía de valores, confesión, misa, comunión, oración (tiempo/forma), devoción a la Virgen, formación, examen, confianza, obediencia, pureza, pobreza.",
  horizontal: "Caridad (casa, amigos, enfermos), perdón, amabilidad, limosna, apostolado (oración, ejemplo, palabra).",
  interior: "Cumplimiento del deber, puntualidad, orden, constancia, dominio propio, carácter, humildad, sencillez, aceptación de cruces, abnegación, penitencias.",
  others: "Ideas, planes, proyectos, dudas, preguntas, permisos."
};

const EMPTY_SESSION: SessionData = {
  general: '',
  vertical: '',
  horizontal: '',
  interior: '',
  others: '',
  agenda: ''
};

export const JournalView: React.FC<JournalViewProps> = ({ entries, setEntries, role }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<SessionData>(EMPTY_SESSION);
  const [expandedSection, setExpandedSection] = useState<string | null>('general');
  const [isGeneratingAgenda, setIsGeneratingAgenda] = useState(false);

  const handleSave = () => {
    const newSession: DirectionSession = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' }),
      data: formData,
      sharedWithDirector: true,
      reviewed: false
    };
    setEntries([newSession, ...entries]);
    setFormData(EMPTY_SESSION);
    setIsEditing(false);
  };

  const handleGenerateAgenda = async () => {
    setIsGeneratingAgenda(true);
    try {
      const apiKey = process.env.API_KEY || '';
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `
        Actúa como un asistente experto en dirección espiritual.
        Analiza las siguientes notas preparatorias de un dirigido (basadas en el esquema de 5 puntos) y genera un "Orden del Día" o "Agenda de la Sesión" concisa.
        
        Objetivo: Crear una lista punteada con los temas principales que se deben tratar en la sesión con el director, priorizando lo más importante o problemático.
        Formato de salida: Markdown simple (lista de puntos). No uses negritas excesivas. Sé breve y directo.

        Datos del dirigido:
        1. General: ${formData.general}
        2. Vertical: ${formData.vertical}
        3. Horizontal: ${formData.horizontal}
        4. Interior: ${formData.interior}
        5. Otros: ${formData.others}
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      const generatedText = response.text || '';
      setFormData(prev => ({ ...prev, agenda: generatedText }));
      setExpandedSection('agenda'); // Abrir sección de agenda para ver el resultado
    } catch (error) {
      console.error("Error generating agenda:", error);
      alert("Hubo un problema al generar la agenda. Por favor intenta de nuevo.");
    } finally {
      setIsGeneratingAgenda(false);
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  if (isEditing) {
    return (
      <div className="max-w-4xl mx-auto pb-12 animate-in fade-in slide-in-from-bottom-4">
        <header className="mb-6 flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 shadow-sm sticky top-4 z-20">
          <div>
            <h2 className="text-xl font-bold text-slate-800 serif">Preparando Sesión</h2>
            <p className="text-slate-500 text-xs">Rellena los puntos y genera el orden del día.</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setIsEditing(false)}
              className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors text-sm"
            >
              Cancelar
            </button>
            <button 
              onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-sm text-sm font-medium"
            >
              <Save size={16} />
              Finalizar y Enviar
            </button>
          </div>
        </header>

        <div className="space-y-4">
          <SectionInput 
            title="1º Estado General"
            id="general"
            value={formData.general}
            onChange={(val) => setFormData({...formData, general: val})}
            guide={SCHEMA_GUIDES.general}
            isOpen={expandedSection === 'general'}
            onToggle={() => toggleSection('general')}
          />
          <SectionInput 
            title="2º Dimensión Vertical (Relación con Dios)"
            id="vertical"
            value={formData.vertical}
            onChange={(val) => setFormData({...formData, vertical: val})}
            guide={SCHEMA_GUIDES.vertical}
            isOpen={expandedSection === 'vertical'}
            onToggle={() => toggleSection('vertical')}
          />
          <SectionInput 
            title="3º Dirección Horizontal (Prójimo)"
            id="horizontal"
            value={formData.horizontal}
            onChange={(val) => setFormData({...formData, horizontal: val})}
            guide={SCHEMA_GUIDES.horizontal}
            isOpen={expandedSection === 'horizontal'}
            onToggle={() => toggleSection('horizontal')}
          />
          <SectionInput 
            title="4º Dirección Interior (Carácter y Virtud)"
            id="interior"
            value={formData.interior}
            onChange={(val) => setFormData({...formData, interior: val})}
            guide={SCHEMA_GUIDES.interior}
            isOpen={expandedSection === 'interior'}
            onToggle={() => toggleSection('interior')}
          />
          <SectionInput 
            title="5º Otras Cosas"
            id="others"
            value={formData.others}
            onChange={(val) => setFormData({...formData, others: val})}
            guide={SCHEMA_GUIDES.others}
            isOpen={expandedSection === 'others'}
            onToggle={() => toggleSection('others')}
          />

          {/* Agenda Generation Section */}
          <div className={`bg-white rounded-xl border-2 transition-all duration-300 overflow-hidden ${formData.agenda ? 'border-emerald-100' : 'border-indigo-50'}`}>
            <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <ListChecks className="text-indigo-600" size={20} />
                <h3 className="font-bold text-slate-800">Orden del Día (Agenda)</h3>
              </div>
              <button
                onClick={handleGenerateAgenda}
                disabled={isGeneratingAgenda}
                className="flex items-center gap-2 text-xs bg-indigo-100 text-indigo-700 hover:bg-indigo-200 px-3 py-1.5 rounded-full transition-colors font-medium disabled:opacity-50"
              >
                {isGeneratingAgenda ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                {formData.agenda ? 'Regenerar con IA' : 'Generar con IA'}
              </button>
            </div>
            
            <div className="p-4">
              {!formData.agenda && !isGeneratingAgenda && (
                <div className="text-center py-6 text-slate-400 text-sm">
                  <p>Rellena los puntos anteriores y pulsa "Generar" para obtener una propuesta de agenda.</p>
                </div>
              )}
              {isGeneratingAgenda && (
                <div className="text-center py-8 text-indigo-500 flex flex-col items-center gap-2">
                  <Loader2 size={24} className="animate-spin" />
                  <p className="text-xs">Analizando tus notas y creando agenda...</p>
                </div>
              )}
              {formData.agenda && !isGeneratingAgenda && (
                <textarea 
                  className="w-full h-40 p-3 bg-emerald-50/50 border border-emerald-100 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none resize-y text-slate-800 text-sm leading-relaxed font-medium"
                  placeholder="Aquí aparecerá el orden del día..."
                  value={formData.agenda}
                  onChange={(e) => setFormData({...formData, agenda: e.target.value})}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto h-full flex flex-col">
      <header className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 serif">Sesiones de Dirección</h2>
          <p className="text-slate-500 mt-2">
            {role === 'director' 
              ? 'Revisa el Orden del Día y los detalles preparados por tu dirigido.' 
              : 'Historial de tus preparaciones y agendas de sesión.'}
          </p>
        </div>
        {role === 'directee' && (
          <button 
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg shadow-sm transition-all font-medium"
          >
            <Plus size={20} />
            <span>Preparar Sesión</span>
          </button>
        )}
      </header>

      <div className="flex-1 overflow-y-auto pb-12 space-y-8">
        {entries.length > 0 ? (
          entries.map((session) => (
            <div key={session.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden group">
              <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center group-hover:bg-slate-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-indigo-600">
                    <Calendar size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Sesión del {session.date}</h3>
                    <p className="text-xs text-slate-500">Preparación completa</p>
                  </div>
                </div>
                {role === 'director' && !session.reviewed && (
                  <span className="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded-full font-medium">
                    Pendiente de revisión
                  </span>
                )}
                {role === 'director' && session.reviewed && (
                  <span className="flex items-center gap-1 text-emerald-600 text-xs font-medium">
                    <CheckCheck size={14} /> Revisado
                  </span>
                )}
              </div>
              
              {/* Agenda Section - Prominent */}
              {session.data.agenda && (
                <div className="mx-6 mt-6 p-5 bg-indigo-50/60 rounded-xl border border-indigo-100">
                  <div className="flex items-center gap-2 mb-3 text-indigo-800">
                    <ListChecks size={18} />
                    <h4 className="font-bold text-sm uppercase tracking-wide">Orden del Día (Propuesta)</h4>
                  </div>
                  <div className="prose prose-sm text-slate-700 max-w-none">
                    <p className="whitespace-pre-wrap">{session.data.agenda}</p>
                  </div>
                </div>
              )}

              {/* Detailed Content */}
              <div className="p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <SessionCard title="1. Estado General" content={session.data.general} />
                <SessionCard title="2. Dimensión Vertical" content={session.data.vertical} />
                <SessionCard title="3. Dimensión Horizontal" content={session.data.horizontal} />
                <SessionCard title="4. Dirección Interior" content={session.data.interior} />
                <SessionCard title="5. Otras Cosas" content={session.data.others} />
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-20 bg-slate-50 rounded-xl border border-dashed border-slate-200">
            <FileText size={48} className="mx-auto mb-4 text-slate-300" />
            <h3 className="text-lg font-medium text-slate-700">No hay sesiones registradas</h3>
            <p className="text-slate-500">
              {role === 'directee' 
                ? 'Pulsa "Preparar Sesión" para comenzar tu examen.' 
                : 'El dirigido aún no ha enviado ninguna preparación.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

const SectionInput: React.FC<{
  title: string;
  id: string;
  value: string;
  onChange: (val: string) => void;
  guide: string;
  isOpen: boolean;
  onToggle: () => void;
}> = ({ title, value, onChange, guide, isOpen, onToggle }) => {
  return (
    <div className={`bg-white rounded-xl border transition-all duration-200 ${isOpen ? 'border-indigo-200 shadow-md ring-1 ring-indigo-50' : 'border-slate-200 hover:border-indigo-100'}`}>
      <button 
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 text-left focus:outline-none"
      >
        <span className="font-semibold text-slate-800">{title}</span>
        {isOpen ? <ChevronUp size={20} className="text-indigo-500" /> : <ChevronDown size={20} className="text-slate-400" />}
      </button>
      
      {isOpen && (
        <div className="px-4 pb-4 animate-in fade-in slide-in-from-top-2">
          <div className="mb-3 p-3 bg-indigo-50 rounded-lg text-xs text-indigo-800 leading-relaxed border border-indigo-100 flex gap-2 items-start">
             <div className="mt-0.5"><div className="w-1.5 h-1.5 rounded-full bg-indigo-400"></div></div>
             <span>{guide}</span>
          </div>
          <textarea 
            className="w-full h-32 p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none resize-y text-slate-700 text-sm leading-relaxed"
            placeholder="Escribe aquí tus reflexiones..."
            value={value}
            onChange={(e) => onChange(e.target.value)}
          />
        </div>
      )}
    </div>
  );
};

const SessionCard: React.FC<{ title: string; content: string }> = ({ title, content }) => {
  if (!content) return null;
  return (
    <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">{title}</h4>
      <p className="text-sm text-slate-700 whitespace-pre-wrap font-serif leading-relaxed">
        {content}
      </p>
    </div>
  );
};