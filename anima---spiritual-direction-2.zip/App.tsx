import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { ObjectivesView } from './components/ObjectivesView';
import { JournalView } from './components/JournalView';
import { GeminiAssistant } from './components/GeminiAssistant';
import { Role, Objective, DirectionSession } from './types';
import { BookOpen, CheckCircle2, Calendar, Layout } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  
  // Initialize state from LocalStorage if available
  const [role, setRole] = useState<Role>(() => {
    const saved = localStorage.getItem('anima_role');
    return (saved as Role) || 'directee';
  });
  
  const [objectives, setObjectives] = useState<Objective[]>(() => {
    const saved = localStorage.getItem('anima_objectives');
    return saved ? JSON.parse(saved) : [];
  });

  const [sessions, setSessions] = useState<DirectionSession[]>(() => {
    const saved = localStorage.getItem('anima_sessions');
    return saved ? JSON.parse(saved) : [];
  });

  // Persistence Effects
  useEffect(() => {
    localStorage.setItem('anima_role', role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem('anima_objectives', JSON.stringify(objectives));
  }, [objectives]);

  useEffect(() => {
    localStorage.setItem('anima_sessions', JSON.stringify(sessions));
  }, [sessions]);

  const toggleRole = () => {
    setRole(prev => prev === 'director' ? 'directee' : 'director');
  };

  const Dashboard = () => {
    const activeObjectives = objectives.filter(o => o.status === 'pending').length;
    const completedObjectives = objectives.filter(o => o.status === 'completed').length;
    const pendingReviews = sessions.filter(s => !s.reviewed).length;

    return (
      <div className="max-w-4xl mx-auto animate-in fade-in duration-500 pb-20 md:pb-0">
        <header className="mb-8">
          <h2 className="text-3xl font-bold text-slate-800 serif">
            {role === 'director' ? 'Panel de Dirección' : 'Mi Camino Espiritual'}
          </h2>
          <p className="text-slate-500 mt-2">
            Resumen de actividad y progreso reciente.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-indigo-100">
            <div className="flex items-center gap-3 mb-2 text-indigo-600">
              <CheckCircle2 size={24} />
              <h3 className="font-semibold">Objetivos</h3>
            </div>
            <p className="text-3xl font-bold text-slate-800">{activeObjectives}</p>
            <p className="text-sm text-slate-500">Pendientes de completar</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-emerald-100">
            <div className="flex items-center gap-3 mb-2 text-emerald-600">
              <BookOpen size={24} />
              <h3 className="font-semibold">Logros</h3>
            </div>
            <p className="text-3xl font-bold text-slate-800">{completedObjectives}</p>
            <p className="text-sm text-slate-500">Objetivos alcanzados</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-amber-100">
            <div className="flex items-center gap-3 mb-2 text-amber-600">
              <Calendar size={24} />
              <h3 className="font-semibold">Sesiones</h3>
            </div>
            <p className="text-3xl font-bold text-slate-800">{sessions.length}</p>
            <p className="text-sm text-slate-500">Informes registrados</p>
          </div>
        </div>

        {role === 'director' && pendingReviews > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-center gap-3 text-amber-800">
            <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
            <span>Tienes {pendingReviews} informe(s) de sesión pendiente(s) de revisión.</span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row font-sans bg-[#f8fafc]">
      <Navigation 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        role={role}
        toggleRole={toggleRole}
      />
      
      <main className="flex-1 md:ml-64 p-4 md:p-8 overflow-y-auto h-screen w-full">
        {currentView === 'dashboard' && <Dashboard />}
        {currentView === 'objectives' && (
          <ObjectivesView 
            objectives={objectives} 
            setObjectives={setObjectives} 
            role={role} 
          />
        )}
        {currentView === 'journal' && (
          <JournalView 
            entries={sessions} 
            setEntries={setSessions} 
            role={role} 
          />
        )}
        {currentView === 'assistant' && (
          <GeminiAssistant role={role} />
        )}
      </main>
    </div>
  );
}