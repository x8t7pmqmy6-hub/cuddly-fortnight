export type Role = 'director' | 'directee';

export type Status = 'pending' | 'in-progress' | 'completed';

export interface Objective {
  id: string;
  title: string;
  description: string;
  category: 'prayer' | 'reading' | 'virtue' | 'action';
  status: Status;
  dueDate?: string;
}

export interface SessionData {
  general: string;   // 1º Estado general
  vertical: string;  // 2º Dimensión vertical
  horizontal: string;// 3º Dirección horizontal
  interior: string;  // 4º Dirección interior
  others: string;    // 5º Otras cosas
  agenda?: string;   // Orden del día generado
}

export interface DirectionSession {
  id: string;
  date: string;
  data: SessionData;
  sharedWithDirector: boolean;
  reviewed: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}